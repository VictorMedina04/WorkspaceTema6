package ejercicio;

public class ExceptionRecaudado extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ExceptionRecaudado() {
		super();
	}

	public ExceptionRecaudado(String string) {
		super(string);
	}

}
