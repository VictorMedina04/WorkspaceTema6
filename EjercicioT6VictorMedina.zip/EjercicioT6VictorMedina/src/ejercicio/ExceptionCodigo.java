package ejercicio;

public class ExceptionCodigo extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ExceptionCodigo() {
		super();
	}

	public ExceptionCodigo(String string) {
		super(string);
	}
}
