package ejercicio;

public class ExceptionOperaciones extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ExceptionOperaciones() {
		super();
	}

	public ExceptionOperaciones(String string) {
		super(string);
	}
}
